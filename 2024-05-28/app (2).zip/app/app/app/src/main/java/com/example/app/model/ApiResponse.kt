package com.example.app.model


data class ApiResponse(
    val success: Boolean,
    val roll: String?,
    val message: String?
)
