package com.example.myactivity.data.model

//총수입
data class IncomeId(
    val user: List<User>,
    val shipmentId: Long
)
